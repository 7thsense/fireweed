import csv,json,re,statistics,sys
from pathlib import Path
base=Path(sys.argv[1]);runs=[];logical=[]
for name in ["control-1","candidate-1","candidate-2","control-2"]:
 p=base/(name+".json")
 if not p.exists() or not p.stat().st_size:continue
 try:d=json.loads(p.read_text())
 except json.JSONDecodeError:continue
 counters={}
 for row in csv.reader((base/(name+"-perf.csv")).read_text().splitlines()):
  if len(row)>4 and row[2] in ("cycles:u","instructions:u"):
   counters[row[2]]={"count":int(row[0]),"running_percent":float(row[4])}
 writes={}
 for line in d["stderr"].splitlines():
  if not line.startswith("projection_io "):continue
  fields=dict(re.findall(r"(\w+)=([^ ]+)",line));kind=fields.pop("class")
  totals=writes.setdefault(kind,{})
  for k,v in fields.items():
   if k=="max_us":totals[k]=max(totals.get(k,0),int(v))
   else:totals[k]=totals.get(k,0)+int(v)
 r=d["result"]
 row={"run":name,"binary_sha256":d["binary_sha256"],"exit_code":d["exit_code"],"diagnostics":d["diagnostics"],"provenance":d["diagnostic_provenance"],"rate":r["completed_lifecycles_per_s"],"cpu_ms_per_recipient":(d["user_cpu_s"]+d["system_cpu_s"])*1000/(r["items"]*8),"rss_gib":d["max_rss_kib"]/2**20,"counters":counters,"projection_writes":writes}
 runs.append(row)
 fields=["items","verified","purged","failed","delivered","pending","leased","retries","claims","initial_payload_bytes","payload_replacements","payload_replacement_bytes","handler_rows"]
 counts=[{"shard":s["shard"],"campaign":c["campaign"],"cycle":n,**{k:cycle[k] for k in fields}} for s in r["shards"] for c in s["campaigns"] for n,cycle in enumerate(c["cycles"])]
 logical.append(sorted(counts,key=lambda row:(row["shard"],row["campaign"],row["cycle"])))
result={"scope":"Balanced eight-cycle diagnostic comparison, not sustained qualification; VFS times overlap and host counters are a different accounting layer","runs":runs,"complete":len(runs)==4,"same_logical_work":bool(logical) and all(x==logical[0] for x in logical)}
if len(runs)==4:
 control=[r for r in runs if r["run"].startswith("control")];candidate=[r for r in runs if r["run"].startswith("candidate")]
 getters={"rate":lambda r:r["rate"],"cpu_ms_per_recipient":lambda r:r["cpu_ms_per_recipient"],"rss_gib":lambda r:r["rss_gib"],"instructions":lambda r:r["counters"]["instructions:u"]["count"],"cycles":lambda r:r["counters"]["cycles:u"]["count"],"wal_bytes":lambda r:r["projection_writes"]["wal"]["requested_bytes"]}
 result["means"]={}
 for key,get in getters.items():
  a=statistics.mean(map(get,control));b=statistics.mean(map(get,candidate));result["means"][key]={"control":a,"candidate":b,"candidate_change_percent":100*(b/a-1)}
print(json.dumps(result,indent=2))

#[cfg(test)]
mod metadata_human_serde_compatibility {
    use super::*;
    use serde::Deserialize;
    use serde::de::value::{
        Error, F64Deserializer, I64Deserializer, I128Deserializer, U128Deserializer,
    };

    #[test]
    fn human_readable_wide_integer_inputs_preserve_i64_limits() {
        for n in [i64::MIN, 0, 42, i64::MAX] {
            assert_eq!(
                MetadataValue::deserialize(I128Deserializer::<Error>::new(n as i128)).unwrap(),
                MetadataValue::Integer(n)
            );
        }
        for n in [0_u128, 42, i64::MAX as u128] {
            assert_eq!(
                MetadataValue::deserialize(U128Deserializer::<Error>::new(n)).unwrap(),
                MetadataValue::Integer(n as i64)
            );
        }
        for n in [
            i128::MIN,
            i64::MIN as i128 - 1,
            i64::MAX as i128 + 1,
            i128::MAX,
        ] {
            assert!(MetadataValue::deserialize(I128Deserializer::<Error>::new(n)).is_err());
        }
        for n in [i64::MAX as u128 + 1, u128::MAX] {
            assert!(MetadataValue::deserialize(U128Deserializer::<Error>::new(n)).is_err());
        }
    }

    #[test]
    fn non_json_nonfinite_inputs_keep_existing_null_semantics() {
        // JSON text cannot contain these values. The generic human-readable
        // Serde API previously passed them through serde_json::Value as null.
        for n in [f64::NAN, f64::INFINITY, f64::NEG_INFINITY] {
            assert_eq!(
                MetadataValue::deserialize(F64Deserializer::<Error>::new(n)).unwrap(),
                MetadataValue::Null
            );
        }
        for n in [0.0, -0.0, 1.0, 1.5] {
            assert!(MetadataValue::deserialize(F64Deserializer::<Error>::new(n)).is_err());
        }
    }

    struct SomeValue<D>(D);

    impl<'de, D: serde::Deserializer<'de>> serde::Deserializer<'de> for SomeValue<D> {
        type Error = D::Error;

        fn deserialize_any<V: serde::de::Visitor<'de>>(
            self,
            visitor: V,
        ) -> Result<V::Value, D::Error> {
            visitor.visit_some(self.0)
        }

        serde::forward_to_deserialize_any! {
            bool i8 i16 i32 i64 i128 u8 u16 u32 u64 u128 f32 f64 char str string
            bytes byte_buf option unit unit_struct newtype_struct seq tuple
            tuple_struct map struct enum identifier ignored_any
        }
    }

    #[test]
    fn human_readable_some_value_unwraps_its_metadata_value() {
        assert_eq!(
            MetadataValue::deserialize(SomeValue(I64Deserializer::<Error>::new(7))).unwrap(),
            MetadataValue::Integer(7)
        );
        assert_eq!(
            MetadataValue::deserialize(SomeValue(SomeValue(I64Deserializer::<Error>::new(8))))
                .unwrap(),
            MetadataValue::Integer(8)
        );
    }
}

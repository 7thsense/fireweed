from pathlib import Path
import hashlib,json,os,re,subprocess,time
repo=Path('/home/erik/Projects/fireweed')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head.startswith('0ea4fc24')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
binary=repo/'target/release/fireweed-workload'
assert not subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True).stdout.strip()
base=repo/'target/workflow-capacity/projection-read-trace-20260916';base.mkdir(exist_ok=False)
with binary.open('rb') as f: sha=hashlib.file_digest(f,'sha256').hexdigest()
prov={'diagnostic_only':True,'build_source_head':head,'executable_sha256':sha,'purpose':'eight-cycle unchanged original-row campaign; projection main/WAL VFS requested read/write counters; not hardware bytes or exact cache misses; not qualification'}
provenance=base/'provenance.json';provenance.write_text(json.dumps(prov,indent=2)+'\n')
args=['--profile','campaign','--campaign-metadata','--campaign-timestamp-priority','--items','1000000','--batch','1000','--purge-batch','8000','--shards','64','--workers','2','--load-workers','2','--recycle','--cycles','8','--deadline-seconds','1800','--diagnostic-provenance',str(provenance)]
env=dict(os.environ)
for key in ['FIREWEED_PROJECTION_IO_TRACE','FIREWEED_SQL_TRACE','FIREWEED_LOG_TRACE','FIREWEED_APPLY_TRACE','OBJECT_LOG_LOCAL_PUBLISH_TRACE','OBJECT_LOG_FLUSH_RUNTIME_THREADS','LD_PRELOAD']:
 assert key not in env,key
env['FIREWEED_PROJECTION_IO_TRACE']='1'
monitor=None;prefix=base/'device';stop=base/'device.stop';pidfile=base/'device.pid'
with (base/'campaign.json').open('w') as output:
 runner=subprocess.Popen(['python3','scripts/perf/workflow-capacity.py',*args],cwd=repo,env=env,stdout=output)
 while runner.poll() is None:
  ids=subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True,text=True).stdout.split()
  assert len(ids)<=1
  if ids and monitor is None:
   pidfile.write_text(ids[0]);monitor=subprocess.Popen(['python3','/tmp/fireweed-device-monitor-v3.py',str(prefix)+'.jsonl',str(stop),str(pidfile)])
   print('workload pid',ids[0],'binary',sha,flush=True)
  time.sleep(1)
if monitor is not None:
 stop.touch();monitor.wait(timeout=5)
 with (base/'device-summary.json').open('w') as out:
  subprocess.run(['python3','/tmp/fireweed-device-summary-v3.py',str(prefix)+'.jsonl'],stdout=out,check=True)
d=json.loads((base/'campaign.json').read_text());assert runner.returncode==0 and d['exit_code']==0,d.get('stderr')
print('rate',d['result']['completed_lifecycles_per_s'],'CPU-ms/recipient',(d['user_cpu_s']+d['system_cpu_s'])/8000,'peak-RSS-GiB',d['max_rss_kib']/2**20,flush=True)

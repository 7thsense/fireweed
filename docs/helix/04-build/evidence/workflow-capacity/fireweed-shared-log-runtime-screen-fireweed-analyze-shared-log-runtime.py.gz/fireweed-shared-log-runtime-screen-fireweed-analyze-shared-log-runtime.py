import json,statistics,subprocess,sys
from pathlib import Path
base=Path(sys.argv[1])
result=json.loads(subprocess.check_output(['python3','/tmp/fireweed-analyze-lease-index-counters.py',str(base)],text=True))
for r in result['runs']:
 name=r['run'];d=json.loads((base/(name+'.json')).read_text())
 samples=[json.loads(line) for line in (base/(name+'-threads.jsonl')).read_text().splitlines()]
 r['thread_samples']=len(samples)
 r['maximum_sampled_threads']=max(s['Threads'] for s in samples)
 r['median_sampled_threads']=statistics.median(s['Threads'] for s in samples)
 for key in ['voluntary_context_switches','involuntary_context_switches']:
  r[key]=d[key]
if result['complete']:
 for key in ['maximum_sampled_threads','median_sampled_threads','voluntary_context_switches','involuntary_context_switches']:
  control=statistics.mean(r[key] for r in result['runs'] if r['run'].startswith('control'))
  candidate=statistics.mean(r[key] for r in result['runs'] if r['run'].startswith('candidate'))
  result['means'][key]={'control':control,'candidate':candidate,'candidate_change_percent':100*(candidate/control-1)}
result['limits']='Thread counts are sampled process totals, including blocking workers, not an exact count of runtime workers. Lower counts do not by themselves prove a throughput improvement.'
print(json.dumps(result,indent=2))

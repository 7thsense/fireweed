from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time,tempfile,signal
repo=Path('/home/erik/Projects/fireweed')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert not subprocess.check_output(['git','diff','HEAD','--','crates/fireweed-core/src/domain.rs'],cwd=repo).strip()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
base=repo/'target/workflow-capacity/projection-io-isolation-sustained-20260916'
base.mkdir(exist_ok=False)
# Reuse the exact checked-in recorder with only explicit repo/executable selection.
source=(repo/'scripts/perf/workflow-capacity.py').read_text()
source=source.replace('from workflow_storage_monitor import WalMonitor', "sys.path.insert(0, '/home/erik/Projects/fireweed/scripts/perf')\nfrom workflow_storage_monitor import WalMonitor")
source=source.replace('repo = Path(__file__).resolve().parents[2]', "repo = Path('/home/erik/Projects/fireweed')")
source=source.replace('binary = repo / "target/release/fireweed-workload"', 'binary = Path(os.environ["FIREWEED_DIAGNOSTIC_BINARY"])')
# Count only the workload process and its threads, not the Python recorder.
source=source.replace('command = [str(binary), *args]', 'workload_command = [str(binary), *args]\ncommand = ["perf", "stat", "-x,", "-o", os.environ["FIREWEED_PERF_COUNTER_OUTPUT"], "-e", "cycles:u,instructions:u", "--", *workload_command]')
source=source.replace('monitor = WalMonitor(projection_root, pid=child.pid)', '# perf is a wrapper: find its actual workload child for memory sampling.\n    monitored_pid = None\n    for _ in range(1000):\n        children_path = Path(f"/proc/{child.pid}/task/{child.pid}/children")\n        try:\n            children = children_path.read_text().split()\n        except FileNotFoundError:\n            children = []\n        if children:\n            assert len(children) == 1, children\n            monitored_pid = int(children[0])\n            break\n        time.sleep(0.001)\n    assert monitored_pid is not None, "perf did not start workload"\n    monitor = WalMonitor(projection_root, pid=monitored_pid)')
recorder=Path('/tmp/fireweed-projection-io-isolation-sustained-recorder.py');recorder.write_text(source)
binaries=[Path('/tmp/fireweed-workload-before-directory-sync-sharing')]*2
def digest(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
hashes=[digest(p) for p in binaries]
assert hashes[1]=='9f54d1207211f5c12104bac95e70289479d2fdecd53baa7562926ae60e6a3763'
assert hashes[0]==hashes[1]
args=['--profile','campaign','--campaign-metadata','--campaign-timestamp-priority','--items','1000000','--batch','1000','--purge-batch','8000','--shards','64','--workers','2','--load-workers','2','--recycle','--cycles','8','--deadline-seconds','900']
records=[]
for name,index,origin in [('control-1',1,'4f4acde08a76d2a94ecbc08443a49d9f38003e39'),('candidate-1',0,'4f4acde08a76d2a94ecbc08443a49d9f38003e39'),('candidate-2',0,'4f4acde08a76d2a94ecbc08443a49d9f38003e39'),('control-2',1,'4f4acde08a76d2a94ecbc08443a49d9f38003e39')]:
 binary=binaries[index]
 for b in binaries:
  assert not subprocess.run(['pgrep','-f','^'+re.escape(str(b))+r'( |$)'],capture_output=True).stdout.strip(), 'Other workload active'
 provenance={'diagnostic_only':True,'build_source_head':origin,'executable_sha256':hashes[index],'recorder_source_head':head,'recorder_sha256':digest(recorder),'purpose':'ABBA eight-cycle exact-binary disk/tmpfs/tmpfs/disk projection I/O isolation; disk-backed log throughout; not sustained qualification'}
 projection_directory=tempfile.TemporaryDirectory(prefix='fireweed-projection-isolation-',dir='/dev/shm') if index==0 else None
 run_args=[*args,*(['--projection-root',projection_directory.name] if projection_directory else [])]
 provenance['projection_medium']='tmpfs' if projection_directory else 'disk'
 provenance['log_medium']='disk'
 prov=base/(name+'-provenance.json');prov.write_text(json.dumps(provenance,indent=2)+'\n')
 output=base/(name+'.json')
 assert 'FIREWEED_PROJECTION_IO_TRACE' not in os.environ
 env=dict(os.environ,FIREWEED_DIAGNOSTIC_BINARY=str(binary),FIREWEED_PERF_COUNTER_OUTPUT=str(base/(name+'-perf.csv')),FIREWEED_PROJECTION_IO_TRACE='1',OBJECT_LOG_LOCAL_PUBLISH_TRACE='1')
 for key in ['FIREWEED_LOG_TRACE','FIREWEED_APPLY_TRACE','FIREWEED_SQL_TRACE','FIREWEED_METRICS_TRACE','FIREWEED_WORKLOAD_TIMING','FIREWEED_WORKLOAD_DEBUG','OBJECT_LOG_FLUSH_RUNTIME_THREADS','LD_PRELOAD']:
  assert key not in env
 with output.open('w') as f:
  runner=subprocess.Popen(['python3',str(recorder),*run_args,'--diagnostic-provenance',str(prov)],cwd=repo,env=env,stdout=f)
  prefix=base/(name+'-device');stop=Path(str(prefix)+'.stop');pidfile=Path(str(prefix)+'.pid');monitor=None
  capacity_aborted=False
  while runner.poll() is None:
   ids=subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True,text=True).stdout.split()
   assert len(ids)<=1
   if projection_directory:
    st=os.statvfs(projection_directory.name)
    allocations=[p.stat().st_blocks*512 for p in Path(projection_directory.name).glob('shard-*/projection.db*') if p.is_file()]
    sample={'monotonic_s':time.monotonic(),'available_bytes':st.f_bavail*st.f_frsize,'projection_allocated_bytes':sum(allocations),'sample_interval_s':1,'rss_excludes_tmpfs_file_pages':True}
    with (base/(name+'-tmpfs-allocation-samples.jsonl')).open('a') as tf:tf.write(json.dumps(sample)+'\n')
    if sample['available_bytes']<1024**3 and ids and not capacity_aborted:
     capacity_aborted=True
     (base/(name+'-capacity-abort.json')).write_text(json.dumps(sample,indent=2)+'\n')
     os.kill(int(ids[0]),signal.SIGTERM)
   if ids:
    try:
     status=Path('/proc/'+ids[0]+'/status').read_text()
     counts={key:int(match[1]) for key in ['Threads','VmRSS'] if (match:=re.search(r'^'+key+r':\s+(\d+)',status,re.M))}
     with (base/(name+'-threads.jsonl')).open('a') as tf:
      if len(counts)==2:tf.write(json.dumps({'monotonic_s':time.monotonic(),'pid':ids[0],**counts})+'\n')
    except FileNotFoundError:pass
   if ids and monitor is None:
    pidfile.write_text(ids[0]); monitor=subprocess.Popen(['python3','/tmp/fireweed-device-monitor-v3.py',str(prefix)+'.jsonl',str(stop),str(pidfile)])
    print(name,'pid',ids[0],flush=True)
   time.sleep(1)
  if monitor is not None:
   stop.touch();monitor.wait(timeout=5)
   with Path(str(prefix)+'-summary.json').open('w') as summary:
    subprocess.run(['python3','/tmp/fireweed-device-summary-v3.py',str(prefix)+'.jsonl'],stdout=summary,check=True)
 if projection_directory:
  usage=[]
  for path in Path(projection_directory.name).rglob('*'):
   if path.is_file():
    st=path.stat();usage.append({'path':str(path.relative_to(projection_directory.name)),'bytes':st.st_size,'allocated_bytes':st.st_blocks*512})
  (base/(name+'-tmpfs-storage.json')).write_text(json.dumps({'files':usage,'allocated_bytes':sum(x['allocated_bytes'] for x in usage),'rss_excludes_tmpfs_file_pages':True},indent=2)+'\n')
  projection_directory.cleanup()
 assert not capacity_aborted,'Diagnostic stopped: less than 1 GiB tmpfs space available'
 d=json.loads(output.read_text());assert runner.returncode==0 and d['exit_code']==0,d.get('stderr')
 records.append({'run':name,'rate':d['result']['completed_lifecycles_per_s'],'cpu_ms_per_recipient':(d['user_cpu_s']+d['system_cpu_s'])*1000/8_000_000,'rss_gib':d['max_rss_kib']/2**20,'binary_sha256':d['binary_sha256'],'build_source_head':origin})
 print(json.dumps(records[-1]),flush=True)
(base/'summary.json').write_text(json.dumps(records,indent=2)+'\n')

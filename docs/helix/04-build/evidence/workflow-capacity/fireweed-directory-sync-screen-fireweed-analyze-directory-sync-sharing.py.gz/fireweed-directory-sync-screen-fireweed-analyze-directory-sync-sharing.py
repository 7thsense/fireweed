import json,re,statistics,subprocess,sys
from pathlib import Path
base=Path(sys.argv[1])
r=json.loads(subprocess.check_output(['python3','/tmp/fireweed-analyze-lease-index-counters.py',str(base)],text=True))
for run in r['runs']:
 d=json.loads((base/(run['run']+'.json')).read_text())
 publications=[]
 for line in d['stderr'].splitlines():
  if not line.startswith('local_publish '):continue
  fields={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
  if run['run'].startswith('candidate'):assert 'dir_sync_ops' in fields
  fields.setdefault('dir_sync_ops',1)
  assert fields['dir_sync_ops'] in (0,1)
  publications.append(fields)
 assert publications,'Missing publication accounting'
 count=len(publications);syncs=sum(p['dir_sync_ops'] for p in publications)
 run['publication_accounting']={'successful_publications':count,'directory_syncs':syncs,'directory_syncs_per_publication':syncs/count,'shared_barrier_publications':count-syncs,'shared_barrier_percent':100*(count-syncs)/count,'file_plus_directory_syncs':count+syncs,'published_bytes':sum(p['bytes'] for p in publications),'sum_elapsed_us':sum(p['total_us'] for p in publications),'sum_file_sync_us':sum(p['data_sync_us'] for p in publications),'sum_directory_barrier_us':sum(p['dir_sync_us'] for p in publications)}
if r['complete']:
 for key in ['successful_publications','directory_syncs','file_plus_directory_syncs','published_bytes','directory_syncs_per_publication']:
  a=statistics.mean(x['publication_accounting'][key] for x in r['runs'] if x['run'].startswith('control'))
  b=statistics.mean(x['publication_accounting'][key] for x in r['runs'] if x['run'].startswith('candidate'))
  r['means'][key]={'control':a,'candidate':b,'candidate_change_percent':100*(b/a-1)}
r['publication_limits']='Successful publications only. File-sync count remains one per publication. Control predates explicit dir_sync_ops and always calls directory.sync_all; its count is one per successful publication. Elapsed publication/barrier times overlap and must not be added to workload wall time. Host counters are a separate accounting layer. This traced one-cycle screen is not sustained qualification.'
print(json.dumps(r,indent=2))

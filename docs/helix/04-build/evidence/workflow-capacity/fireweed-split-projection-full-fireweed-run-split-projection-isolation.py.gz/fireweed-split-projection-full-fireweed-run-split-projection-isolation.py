from pathlib import Path
import hashlib,json,os,re,runpy,shutil,signal,subprocess,sys,tempfile,time
repo=Path('/home/erik/Projects/fireweed')
smoke='--smoke' in sys.argv[1:]
base=Path(sys.argv[1]).resolve();assert str(base).startswith(str(repo/'target/workflow-capacity/'))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
dirty=bool(subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip())
assert smoke or not dirty,'Full comparison requires clean source'
binary=repo/'target/release/examples/projection_isolation'
recorder=Path('/tmp/fireweed-split-projection-recorder.py')
capacity=runpy.run_path('/tmp/fireweed-read-user-quota.py')['capacity']
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
preflight={root:capacity(root) for root in ['/tmp','/dev/shm']}
# Half the observed full-control aggregate WAL peaks + main files + 1 GiB,
# rounded upward, on each existing mount. Not a qualification limit.
required_per_mount=17*1024**3 if not smoke else 256*1024**2
assert all(c['conservative_available_bytes']>=required_per_mount for c in preflight.values()),preflight
base.mkdir(exist_ok=False)
(base/'preflight.json').write_text(json.dumps({'capacity':preflight,'required_bytes_per_mount':required_per_mount},indent=2)+'\n')
records=[]
for name,ram in [('control-1',False),('candidate-1',True),('candidate-2',True),('control-2',False)]:
    assert not subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True).stdout.strip()
    routing=Path(tempfile.mkdtemp(prefix=name+'-routes-',dir=base))
    roots=[Path(tempfile.mkdtemp(prefix='fireweed-split-projection-',dir=place)) for place in (['/tmp','/dev/shm'] if ram else [base,base])]
    shards=2 if smoke else 64
    for shard in range(shards):
        target=roots[shard%2]/f'shard-{shard}';target.mkdir();(routing/f'shard-{shard}').symlink_to(target,target_is_directory=True)
    provenance={'diagnostic_only':True,'build_source_head':head,'source_dirty':dirty,'binary_sha256':digest(binary),'recorder_sha256':digest(recorder),'fixture_sha256':digest(repo/'crates/fireweed-workload/examples/projection_isolation.rs'),'purpose':'Serial disk/RAM/RAM/disk eight-cycle high-level campaign API isolation; not qualification','physical_projection_roots':[str(p) for p in roots],'projection_medium':'tmpfs' if ram else 'disk','log_medium':'disk','smoke':smoke}
    prov=base/(name+'-provenance.json');prov.write_text(json.dumps(provenance,indent=2)+'\n')
    args=['--projection-root',str(routing)]
    if smoke:args+=['--items','120','--cycles','1','--shards','2']
    env=dict(os.environ,FIREWEED_DIAGNOSTIC_BINARY=str(binary),FIREWEED_PERF_COUNTER_OUTPUT=str(base/(name+'-perf.csv')),FIREWEED_PROJECTION_IO_TRACE='1',OBJECT_LOG_LOCAL_PUBLISH_TRACE='1')
    for key in ['FIREWEED_LOG_TRACE','FIREWEED_APPLY_TRACE','FIREWEED_SQL_TRACE','FIREWEED_METRICS_TRACE','FIREWEED_WORKLOAD_TIMING','FIREWEED_WORKLOAD_DEBUG','OBJECT_LOG_FLUSH_RUNTIME_THREADS','LD_PRELOAD']:assert key not in env
    prefix=base/(name+'-device');stop=Path(str(prefix)+'.stop');pidfile=Path(str(prefix)+'.pid');monitor=None;aborted=False
    output=base/(name+'.json')
    with output.open('w') as f:
        runner=subprocess.Popen(['python3',str(recorder),*args,'--diagnostic-provenance',str(prov)],cwd=repo,env=env,stdout=f)
        while runner.poll() is None:
            ids=subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True,text=True).stdout.split();assert len(ids)<=1
            if ids and monitor is None:
                pidfile.write_text(ids[0]);monitor=subprocess.Popen(['python3','/tmp/fireweed-device-monitor-v3.py',str(prefix)+'.jsonl',str(stop),str(pidfile)])
                print(name,'pid',ids[0],flush=True)
            allocations=[sum(p.stat().st_blocks*512 for p in root.glob('shard-*/projection.db*') if p.is_file()) for root in roots]
            sample={'monotonic_s':time.monotonic(),'allocated_bytes_by_root':dict(zip(map(str,roots),allocations)),'total_projection_allocated_bytes':sum(allocations),'tmpfs_bytes':sum(allocations) if ram else 0,'rss_excludes_tmpfs_file_pages':True}
            if ram:
                sample['capacity']=[capacity(str(root)) for root in roots]
                if any(c['conservative_available_bytes']<1024**3 for c in sample['capacity']) and ids and not aborted:
                    aborted=True;os.kill(int(ids[0]),signal.SIGTERM)
                    (base/(name+'-capacity-abort.json')).write_text(json.dumps(sample,indent=2)+'\n')
            with (base/(name+'-allocation-samples.jsonl')).open('a') as af:af.write(json.dumps(sample)+'\n')
            time.sleep(1)
        if monitor:
            stop.touch();monitor.wait(timeout=5)
            with Path(str(prefix)+'-summary.json').open('w') as sf:
                completed=subprocess.run(['python3','/tmp/fireweed-device-summary-v3.py',str(prefix)+'.jsonl'],stdout=sf)
            assert smoke or completed.returncode==0
    d=json.loads(output.read_text())
    if aborted or runner.returncode!=0 or d['exit_code']!=0:
        (base/(name+'-retained-projection-roots.json')).write_text(json.dumps({'roots':list(map(str,roots)),'routing':str(routing)},indent=2)+'\n')
        raise RuntimeError(f'{name} failed; all projection files retained; inspect {output}')
    r=d['result'];assert r['not_workflow_qualification'] is True
    assert len(d['projection_storage'])==2*shards
    assert len(d['projection_wal_observation']['peak_bytes'])==shards
    fstype=[m['fstype'] for m in d['projection_filesystem']['filesystems']];assert all((t=='tmpfs')==ram for t in fstype)
    samples=[json.loads(line) for line in (base/(name+'-allocation-samples.jsonl')).read_text().splitlines()]
    record={'run':name,'rate':r['completed_lifecycles_per_s'],'cpu_ms_per_recipient':(d['user_cpu_s']+d['system_cpu_s'])*1000/(120 if smoke else 8_000_000),'rss_gib':d['max_rss_kib']/2**20,'sampled_peak_projection_allocated_bytes':max(s['total_projection_allocated_bytes'] for s in samples),'tmpfs':ram,'binary_sha256':d['binary_sha256']}
    records.append(record);print(json.dumps(record),flush=True)
    (base/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
    for root in roots:shutil.rmtree(root)
    shutil.rmtree(routing)

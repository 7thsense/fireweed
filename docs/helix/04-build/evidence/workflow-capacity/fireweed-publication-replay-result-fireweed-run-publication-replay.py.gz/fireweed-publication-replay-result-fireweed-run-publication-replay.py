from pathlib import Path
import hashlib,json,os,subprocess,time
repo=Path('/home/erik/Projects/fireweed');base=repo/'target/workflow-capacity/publication-replay-20260916';binary=repo/'target/object-log-tests/release/examples/replay_publications';capture=repo/'target/workflow-capacity/publication-capture-20260916'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
assert not subprocess.run(['pgrep','-f','^(/home/erik/Projects/fireweed/target/release/fireweed-workload|/tmp/fireweed-workload-before-directory-sync-sharing|'+str(binary)+') '],capture_output=True).stdout.strip()
for k in ('OBJECT_LOG_LOCAL_PUBLISH_TRACE','FIREWEED_PROJECTION_IO_TRACE','LD_PRELOAD'):assert k not in os.environ,k
base.mkdir(exist_ok=False)
with binary.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
command=[str(binary),str(capture),str(base/'destination'),'32']
provenance={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'binary_sha256':sha,'command':command,'capture_inventory_sha256':hashlib.sha256((capture/'immutable-inventory.json').read_bytes()).hexdigest(),'not_workflow_qualification':True,'process_usage_includes_preload_and_verification':True}
(base/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
stop=base/'device.stop';pidfile=base/'replay.pid'
with (base/'result.json').open('w') as output,(base/'stderr.log').open('w') as errors:
 child=subprocess.Popen(command,cwd=repo,stdout=output,stderr=errors);pidfile.write_text(str(child.pid))
 monitor=subprocess.Popen(['python3','/tmp/fireweed-device-monitor-v3.py',str(base/'device.jsonl'),str(stop),str(pidfile)])
 print('publication replay pid',child.pid,flush=True);started=time.monotonic()
 _,status,usage=os.wait4(child.pid,0);child.returncode=os.waitstatus_to_exitcode(status)
 stop.touch();monitor.wait(timeout=5)
 result={'exit_code':child.returncode,'process_wall_s':time.monotonic()-started,'user_cpu_s':usage.ru_utime,'system_cpu_s':usage.ru_stime,'max_rss_kib':usage.ru_maxrss,'filesystem_input_blocks':usage.ru_inblock,'filesystem_output_blocks':usage.ru_oublock,'process_usage_includes_preload_and_verification':True}
 (base/'usage.json').write_text(json.dumps(result,indent=2)+'\n')
with (base/'device-summary.json').open('w') as f:subprocess.run(['python3','/tmp/fireweed-device-summary-v3.py',str(base/'device.jsonl')],stdout=f,check=True)
assert child.returncode==0,(base/'stderr.log').read_text()[-4000:]
d=json.loads((base/'result.json').read_text());assert len(d['cycles'])==32 and d['verified_objects']==10970*32
print('finished',result,'verified_objects',d['verified_objects'],flush=True)

import sys,bisect,collections,struct
from pathlib import Path
prefix=sys.argv[1]
ranges=[]
for line in Path(prefix+'.maps').read_text().splitlines():
 p=line.split();a,b=(int(x,16) for x in p[0].split('-'));ranges.append((a,b,int(p[2],16),p[-1] if len(p)>5 else '[anonymous]'))
elf=Path("target/release/fireweed-workload").read_bytes()
phoff=struct.unpack_from("<Q",elf,32)[0];phsize,phnum=struct.unpack_from("<HH",elf,54)
segments=[]
for i in range(phnum):
 t,flags,off,va,pa,fs,ms,al=struct.unpack_from("<IIQQQQQQ",elf,phoff+i*phsize)
 if t==1:segments.append((off//4096*4096,off+fs,va-off))
def virtual_offset(off):
 return next(off+delta for start,end,delta in segments if start<=off<end)
syms=[]
for line in Path(prefix+'.symbols').read_text().splitlines():
 p=line.split(maxsplit=2)
 if len(p)==3 and p[1].lower() in ('t','w'):syms.append((int(p[0],16),p[2]))
libsyms=[]
for line in Path("/tmp/fireweed-9500-libc-private.symbols").read_text().splitlines():
 p=line.split(maxsplit=2);libsyms.append((int(p[0],16),p[2]))
libsyms.sort();libaddr=[a for a,b in libsyms]
syms.sort();addresses=[s[0] for s in syms];counts=collections.Counter();total=0
for line in Path(prefix+'.samples').read_text().splitlines():
 try:ip=int(line,16)
 except ValueError:continue
 total+=1
 for a,b,offset,path in ranges:
  if a<=ip<b:
   if path.endswith('/fireweed-workload'):
    i=bisect.bisect_right(addresses,virtual_offset(ip-a+offset))-1
    name=syms[i][1] if i>=0 else '[unknown executable]'
   elif path.endswith("/libc.so.6"):
    i=bisect.bisect_right(libaddr,ip-a+offset)-1;name="libc::"+libsyms[i][1]
   else:name=path
   counts[name]+=1;break
 else:counts['[unmapped]']+=1
print('total',total)
for name,n in counts.most_common(35):print(f'{100*n/max(1,total):6.2f}% {n:7d} {name}')

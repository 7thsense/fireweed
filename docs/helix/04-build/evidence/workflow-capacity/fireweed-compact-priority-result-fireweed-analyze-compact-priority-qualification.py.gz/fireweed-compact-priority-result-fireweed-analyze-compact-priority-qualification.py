from pathlib import Path
import json,sys
sys.path.insert(0,'scripts/perf')
from workflow_capacity_gate import qualify
root=Path(sys.argv[1]);attempt=int(sys.argv[2]);d=json.loads((root/f'campaign-{attempt}.json').read_text());r=d['result']
cycles=[]
for n in range(8):
 cases=[(s['shard'],c['campaign'],c['cycles'][n]) for s in r['shards'] for c in s['campaigns']]
 shard,campaign,c=min(cases,key=lambda x:x[2]['items']/x[2]['wall_s'])
 sizes=[max(c['cycles'][n]['projection_bytes'] for c in s['campaigns']) for s in r['shards']]
 cycles.append({'cycle':n,'slowest_shard':shard,'slowest_campaign':campaign,'equivalent_rate':c['items']/c['wall_s']*128,**{k:c[k] for k in ['load_s','prepare_s','delivery_s','verify_s','purge_s','wall_s']},'main_bytes_by_physical_shard':sizes,'sum_main_bytes':sum(sizes)})
samples=[json.loads(x) for x in Path(f'/tmp/fireweed-compact-priority-untraced-qualification-phase-{2*attempt-1}-device.jsonl').read_text().splitlines()]
windows=[]
for i,a in enumerate(samples[:-10]):
 b=samples[i+10];dt=b['monotonic_s']-a['monotonic_s'];x,y=a['nvme0n1'],b['nvme0n1'];writes=y[4]-x[4]
 windows.append({'start_offset_s':a['monotonic_s']-samples[0]['monotonic_s'],'interval_s':dt,'device_busy_percent':(y[9]-x[9])/dt/10,'host_write_mib_s':(y[6]-x[6])*512/2**20/dt,'write_iops':writes/dt,'mean_write_request_ms':(y[7]-x[7])/max(1,writes),'mean_outstanding_io':(y[10]-x[10])/1000/dt,'mean_write_request_kib':(y[6]-x[6])*.5/max(1,writes),'process_cpu_s_per_s':(b.get('process_cpu_s',0)-a.get('process_cpu_s',0))/dt})
q={str(t):qualify(d,campaign_target=t) for t in [10000,12500]}
result={'scope':'One completed untraced eight-cycle campaign from the serial repeated compact-priority qualification.','head':d['head'],'binary_sha256':d['binary_sha256'],'dirty':d['dirty'],'diagnostics':d['diagnostics'],'child_exit':d['exit_code'],'overall_rate':r['completed_lifecycles_per_s'],'cpu_ms_per_recipient':(d['user_cpu_s']+d['system_cpu_s'])*1000/8000000,'rss_gib':d['max_rss_kib']/2**20,'gates':{t:{'passed':v['passed'],'total_checks':len(v['checks']),'failed_checks':[c for c in v['checks'] if not c['passed']]} for t,v in q.items()},'cycles':cycles,'maximum_busy_rolling_window':max(windows,key=lambda w:w['device_busy_percent']),'interpretation':'Per-cycle main-file materialization and phase times show checkpoint distribution. Device counters are host-wide; request latency includes queueing; the maximum-busy window is not a device bandwidth ceiling. Rolling windows overlap and must not be summed.'}
(root/f'checkpoint-analysis-{attempt}.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:result[k] for k in ['overall_rate','cpu_ms_per_recipient','rss_gib','gates','maximum_busy_rolling_window']})

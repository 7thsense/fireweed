"""Offline bounded WAL page overlap; never opens a database or mutates WALs."""
import json,struct,sys,time
from pathlib import Path

def analyze(path,limit=32768):
 start=time.monotonic()
 with path.open('rb') as f:
  h=f.read(32);magic,version,ps,seq,s1,s2,c1,c2=struct.unpack('>8I',h)
  assert magic in (0x377f0682,0x377f0683) and version==3007000
  assert 512<=ps<=65536 and ps&(ps-1)==0
  order='>' if magic&1 else '<'
  def checksum(buf,c):
   a,b=c
   for x,y in struct.iter_unpack(order+'II',buf):
    a=(a+x+b)&0xffffffff;b=(b+y+a)&0xffffffff
   return a,b
  assert checksum(h[:24],(0,0))==(c1,c2),'header checksum'
  c=(c1,c2);tx=[];pending=[];valid=0;stop='frame_limit'
  for _ in range(limit):
   raw=f.read(ps+24)
   if len(raw)!=ps+24:stop='end_or_partial_frame';break
   page,size,fs1,fs2,fc1,fc2=struct.unpack('>6I',raw[:24])
   if (fs1,fs2)!=(s1,s2):stop='stale_salt';break
   new=checksum(raw[24:],checksum(raw[:8],c))
   if new!=(fc1,fc2):stop='invalid_checksum';break
   assert page>0
   c=new;valid+=1;pending.append(page)
   if size:tx.append(pending);pending=[]
 sets=[set(x) for x in tx];n=sum(map(len,tx))
 pair=[]
 for offset in (0,1):
  saved=sum(len(sets[i]&sets[i+1]) for i in range(offset,len(tx)-1,2))
  pair.append({'offset':offset,'eliminable_frames':saved,'fraction_of_committed_frames':saved/n if n else 0})
 # Best nonoverlapping adjacent pairs, without queue/readiness restrictions.
 older=prev=0
 for i in range(1,len(sets)):
  older,prev=prev,max(prev,older+len(sets[i-1]&sets[i]))
 return dict(path=str(path),file_bytes=path.stat().st_size,page_size=ps,frame_limit=limit,
   valid_frames=valid,committed_transactions=len(tx),committed_frames=n,
   uncommitted_or_limit_cut_frames=len(pending),stop=stop,
   within_transaction_duplicate_frames=n-sum(map(len,sets)),
   fixed_adjacent_pairs=pair,best_adjacent_pair_eliminable_frames=prev,
   best_adjacent_pair_fraction=prev/n if n else 0,elapsed_s=time.monotonic()-start)
if __name__=='__main__':
 results=[analyze(Path(p)) for p in sys.argv[1:]]
 print(json.dumps({'caveat':'Historical final WAL generation sample; page overlap upper bound ignores queue identity, admission order, readiness, transaction limits and isolation. Not a measured batching speedup.', 'results':results},indent=2))

from pathlib import Path
import json,hashlib,re,subprocess,sys
repo=Path('/home/erik/Projects/fireweed');base=repo/'target/workflow-capacity/idle-wait-untraced-repeat-20260916'
summary=json.loads(subprocess.check_output(['python3','/tmp/fireweed-summarize-direct-json-qualification.py',str(base)],cwd=repo,text=True))
assert summary['complete'] and summary['same_binary'] and summary['same_head'] and summary['all_stretch_pass']
assert all(r['targets']['10000']['passed'] and r['exit_code']==0 and not r['dirty'] and not r['diagnostics'] for r in summary['reports'].values())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
assert not subprocess.run(['pgrep','-f','^'+str(repo/'target/release/fireweed-workload')+r'( |$)'],capture_output=True).stdout.strip()
phases=json.loads(Path('/tmp/fireweed-idle-wait-untraced-qualification-phases.json').read_text())
assert phases['runner_exit']==0 and len(phases['phases'])==4
for r in summary['reports'].values():
 assert r['head']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
 assert r['binary_sha256']==hashlib.sha256((repo/'target/release/fireweed-workload').read_bytes()).hexdigest()
log=Path('/tmp/fireweed-idle-wait-public-tests.log').read_text()
counts=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored',log)
assert [sum(int(c[i]) for c in counts) for i in range(3)]==[12,0,0]
for n in (1,2):
 d=json.loads((base/f'campaign-{n}.json').read_text());r=d['result']
 assert r['items']==1000000 and r['cycles']==8 and r['physical_shards']==64
 assert r['enrichment_storage']=='row_metadata' and r['priority_workload']=='availability_timestamp'
 assert r['stage_limits']==[500,200,500] and r['faults'] and r['includes_purge']
 assert d['qualification']['passed'] and len(d['qualification']['checks'])==2278
 assert r['progress_interval_ms']==1000 and r['purge_batch']==8000 and r['batch']==1000
summary['completion_audit']={'public_test_counts_pass_fail_ignore':[12,0,0],'serial_runner_exit':0,'serial_phases':4,'source_and_binary_match_current_tree':True,'full_campaign_rows_per_run':8000000,'resident_rows':1000000,'stage_limits':[500,200,500],'scope':'Local filesystem log/native Turso; public original-row campaign with deterministic enrichment/delivery stubs; production workflow and resource gates unchanged. External provider/network capacity is outside this test.'}
(base/'qualification-audit.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

import json,re,statistics,subprocess,sys
from pathlib import Path
base=Path(sys.argv[1])
r=json.loads(subprocess.check_output(['python3','/tmp/fireweed-analyze-projection-isolation-sustained-base.py',str(base)],text=True))
for run in r['runs']:
 d=json.loads((base/(run['run']+'.json')).read_text())
 publications=[]
 for line in d['stderr'].splitlines():
  if not line.startswith('local_publish '):continue
  fields={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',line)}
  fields.setdefault('dir_sync_ops',1)
  assert fields['dir_sync_ops'] in (0,1)
  publications.append(fields)
 assert publications,'Missing publication accounting'
 count=len(publications);syncs=sum(p['dir_sync_ops'] for p in publications)
 run['publication_accounting']={'successful_publications':count,'directory_syncs':syncs,'directory_syncs_per_publication':syncs/count,'shared_barrier_publications':count-syncs,'shared_barrier_percent':100*(count-syncs)/count,'file_plus_directory_syncs':count+syncs,'published_bytes':sum(p['bytes'] for p in publications),'sum_elapsed_us':sum(p['total_us'] for p in publications),'sum_file_sync_us':sum(p['data_sync_us'] for p in publications),'sum_directory_barrier_us':sum(p['dir_sync_us'] for p in publications)}
if r['complete']:
 for key in ['successful_publications','directory_syncs','file_plus_directory_syncs','published_bytes','directory_syncs_per_publication']:
  a=statistics.mean(x['publication_accounting'][key] for x in r['runs'] if x['run'].startswith('control'))
  b=statistics.mean(x['publication_accounting'][key] for x in r['runs'] if x['run'].startswith('candidate'))
  r['means'][key]={'control':a,'candidate':b,'candidate_change_percent':100*(b/a-1)}
r['publication_limits']='Successful publications only. File-sync count remains one per publication. Both configurations predate explicit dir_sync_ops and always call directory.sync_all; its count is one per successful publication. Elapsed publication/barrier times overlap and must not be added to workload wall time. Host counters are a separate accounting layer. This traced eight-cycle diagnostic is not sustained qualification.'
r['configuration']={'control':'disk projection and log','candidate':'tmpfs projection, disk log','same_executable_required':True}
assert len({x['binary_sha256'] for x in r['runs']})<=1
for run in r['runs']:
 d=json.loads((base/(run['run']+'.json')).read_text())
 run['projection_storage']=d.get('projection_storage',{})
 p=base/(run['run']+'-tmpfs-storage.json')
 if p.exists():run['tmpfs_allocated_bytes']=json.loads(p.read_text())['allocated_bytes']
 run['device_summary']=json.loads((base/(run['run']+'-device-summary.json')).read_text())
sys.path.insert(0,'scripts/perf')
from workflow_capacity_gate import qualify
for run in r['runs']:
 d=json.loads((base/(run['run']+'.json')).read_text());result=d['result']
 cycles=[]
 for n in range(8):
  cases=[(shard['shard'],c['campaign'],c['cycles'][n]) for shard in result['shards'] for c in shard['campaigns']]
  shard,campaign,c=min(cases,key=lambda x:x[2]['items']/x[2]['wall_s'])
  cycles.append({'cycle':n,'slowest_shard':shard,'slowest_campaign':campaign,'minimum_equivalent_rate':c['items']/c['wall_s']*128,**{k:c[k] for k in ['load_s','prepare_s','delivery_s','verify_s','purge_s','wall_s']}})
 run['cycles']=cycles
 run['gates']={}
 for target in (10000,12500):
  q=qualify(d,campaign_target=target)
  run['gates'][str(target)]={'passed':q['passed'],'total_checks':len(q['checks']),'failed_checks':[c for c in q['checks'] if not c['passed']]}
 p=base/(run['run']+'-tmpfs-allocation-samples.jsonl')
 if p.exists():
  samples=[json.loads(line) for line in p.read_text().splitlines()]
  run['tmpfs_sampled_peak_allocated_bytes']=max(x['projection_allocated_bytes'] for x in samples)
  run['tmpfs_minimum_available_bytes']=min(x['available_bytes'] for x in samples)
print(json.dumps(r,indent=2))

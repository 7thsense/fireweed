import collections,json,os,re,subprocess,time
from pathlib import Path
binary='/home/erik/Projects/fireweed/target/release/fireweed-workload'
pids=subprocess.run(['pgrep','-f','^'+re.escape(binary)+' '],capture_output=True,text=True).stdout.split()
assert len(pids)<=1, 'More than one workload process'
result={'observed_monotonic_s':time.monotonic(),'observed_unix_s':time.time(),'pids':pids}
if pids:
 pid=pids[0]
 try:
  command=Path(f'/proc/{pid}/cmdline').read_bytes().decode().split('\0')
  result['command']=command
  if '--profile' in command and command[command.index('--profile')+1]=='campaign':
   count=int(command[command.index('--shards')+1])*2
   stream=Path(f'/proc/{pid}/fd/2');before=stream.stat();cases=collections.defaultdict(dict);last_was_cycle=False;last_cycle=None
   with stream.open() as f:
    for line in f:
     m=re.match(r'campaign_cycle_complete shard=(\d+) campaign=(\d+) (.*)',line)
     last_was_cycle=False
     if not m:continue
     try:c=json.loads(m[3])
     except json.JSONDecodeError:continue
     cases[c['cycle']][(int(m[1]),int(m[2]))]=c;last_cycle=c['cycle'];last_was_cycle=True
   after=stream.stat();cycles=[]
   for cycle,rows in sorted(cases.items()):
    item={'cycle':cycle,'completed_campaigns':len(rows),'required_campaigns':count}
    if len(rows)==count:
     main={}
     for (shard,campaign),c in rows.items():main[shard]=max(main.get(shard,0),c['projection_bytes'])
     item.update({'minimum_equivalent_rate':min(c['items']/c['wall_s']*count for c in rows.values()),'maximum_progress_p95_s':max(c['progress_p95_s'] for c in rows.values()),'main_files_materialized':sum(v>4096 for v in main.values()),'largest_main_file_bytes':max(main.values()),'maximum_rss_kib':max(c['process_rss_kib'] for c in rows.values())})
    cycles.append(item)
   result['cycles']=cycles
   if last_was_cycle and before.st_mtime_ns==after.st_mtime_ns and len(cases[last_cycle])==count:
    result['last_complete_cycle_log_mtime']={'cycle':last_cycle,'unix_ns':after.st_mtime_ns,'scope':'last report write time, not a phase start or a clock used by the qualification gate'}
 except FileNotFoundError:result['observation']='workload exited during observation; inspect runner'
with Path('/tmp/fireweed-staggered-checkpoints-repaired-live-observations.jsonl').open('a') as f:f.write(json.dumps(result)+'\n')
print(json.dumps(result,indent=2))

from pathlib import Path
import json
original=Path('target/workflow-capacity/split-projection-sustained-20260916').resolve()
retry=Path('target/workflow-capacity/split-projection-final-control-retry-20260916').resolve()
out=Path('target/workflow-capacity/split-projection-combined-20260916').resolve()
out.mkdir(exist_ok=True)
mapping={}
for name in ['control-1','candidate-1','candidate-2','control-2']:
 source=retry if name=='control-2' else original
 d=json.loads((source/(name+'.json')).read_text())
 assert d['exit_code']==0
 if name=='control-2':assert d['workload_pid_attachment']['error'] is None
 for p in source.glob(name+'*'):
  if p.is_file():
   dest=out/p.name
   if not dest.exists():dest.symlink_to(p)
 mapping[name]=str(source)
(out/'source-mapping.json').write_text(json.dumps({'runs':mapping,'excluded_attempt':str(original/'control-2.json'),'reason':'Original final control recorder attachment failed before reporting. Replacement uses the same binary and workload with corrected observer discovery; no successful runs repeated.'},indent=2)+'\n')
print(out)

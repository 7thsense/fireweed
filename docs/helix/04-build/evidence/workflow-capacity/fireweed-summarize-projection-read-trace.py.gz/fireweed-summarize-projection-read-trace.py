from pathlib import Path
import json,re,sys
sys.path.insert(0,'scripts/perf')
from workflow_capacity_gate import qualify
base=Path(sys.argv[1]);d=json.loads((base/'campaign.json').read_text());io={}
for line in d['stderr'].splitlines():
 if not line.startswith(('projection_io ','projection_read ')):continue
 kind=line.split()[0];values=dict(re.findall(r'(\w+)=(\S+)',line));key=kind+':'+values.pop('class');totals=io.setdefault(key,{'handles':0});totals['handles']+=1
 for key,value in values.items():totals[key]=max(totals.get(key,0),int(value)) if key=='max_us' else totals.get(key,0)+int(value)
gate=qualify(d,campaign_target=12500)
print(json.dumps({'vfs':io,'rate':d['result']['completed_lifecycles_per_s'],'cpu_ms_per_recipient':(d['user_cpu_s']+d['system_cpu_s'])/8000,'binary_sha256':d['binary_sha256'],'head':d['head'],'diagnostics':d['diagnostics'],'failed_stretch_checks':[c for c in gate['checks'] if not c['passed']],'cycle_rates':[c['actual'] for c in gate['checks'] if c['name'].endswith('_slowest_campaign_equivalent_rate')]},indent=2))

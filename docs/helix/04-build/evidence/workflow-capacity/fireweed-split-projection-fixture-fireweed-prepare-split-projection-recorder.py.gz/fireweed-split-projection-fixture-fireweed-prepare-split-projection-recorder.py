from pathlib import Path
repo=Path('/home/erik/Projects/fireweed')
source=(repo/'scripts/perf/workflow-capacity.py').read_text()
source=source.replace('from workflow_storage_monitor import WalMonitor', "sys.path.insert(0, '/home/erik/Projects/fireweed/scripts/perf')\nfrom workflow_storage_monitor import WalMonitor")
source=source.replace('repo = Path(__file__).resolve().parents[2]', "repo = Path('/home/erik/Projects/fireweed')")
source=source.replace('binary = repo / "target/release/fireweed-workload"', 'binary = Path(os.environ["FIREWEED_DIAGNOSTIC_BINARY"])')
source=source.replace('command = [str(binary), *args]', 'workload_command = [str(binary), *args]\ncommand = ["perf", "stat", "-x,", "-o", os.environ["FIREWEED_PERF_COUNTER_OUTPUT"], "-e", "cycles:u,instructions:u", "--", *workload_command]')
source=source.replace('monitor = WalMonitor(projection_root, pid=child.pid)', '''monitored_pid = None
    for _ in range(1000):
        try:
            children = Path(f"/proc/{child.pid}/task/{child.pid}/children").read_text().split()
        except FileNotFoundError:
            children = []
        if children:
            assert len(children) == 1
            monitored_pid = int(children[0])
            break
        time.sleep(0.001)
    assert monitored_pid is not None, "perf did not start workload"
    monitor = WalMonitor(projection_root, pid=monitored_pid)''')
# An explicit glob follows the fixture's shard symlinks. rglob alone does not.
source=source.replace('report["projection_storage"] = storage_usage(projection_root)', '''report["projection_storage"] = {}
        for path in projection_root.glob("shard-*/projection.db*"):
            if path.is_file():
                st = path.stat()
                report["projection_storage"][str(path.relative_to(projection_root))] = {"files": 1, "bytes": st.st_size, "allocated_bytes": st.st_blocks * 512}
        report["projection_routes"] = {path.name: str(path.resolve()) for path in projection_root.glob("shard-*")}''')
source=source.replace('report["projection_filesystem"] = json.loads(subprocess.check_output([', 'report["projection_routing_filesystem"] = json.loads(subprocess.check_output([')
needle='    if child.returncode == 0:\n'
assert source.count(needle)==1
source=source.replace(needle, '''        physical_roots = sorted({str(path.resolve().parent) for path in projection_root.glob("shard-*")})
        report["projection_filesystem"] = {"filesystems": [mount for root in physical_roots for mount in json.loads(subprocess.check_output(["findmnt", "--json", "--target", root]))["filesystems"]]}
''' + needle)
output=Path('/tmp/fireweed-split-projection-recorder.py');output.write_text(source);compile(source,str(output),'exec')

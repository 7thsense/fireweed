from pathlib import Path
import hashlib,json,os,re,subprocess,time
base=Path(__file__).resolve().parent
binary=base/'target/release/fireweed-workload'
with binary.open('rb') as f:sha=hashlib.file_digest(f,'sha256').hexdigest()
assert sha=='5d0ac2955435d238bb631b9e432e8834c6fe5d9f53964825f70d98097df9be8f'
assert not subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True).stdout.strip()
for k in ('FIREWEED_PROJECTION_IO_TRACE','FIREWEED_APPLY_TRACE','FIREWEED_LOG_TRACE','LD_PRELOAD','OBJECT_LOG_FLUSH_RUNTIME_THREADS'):
 assert k not in os.environ,k
out=base/'results';out.mkdir(exist_ok=False)
hardware={}
for name,command in [('hostname',['hostname']),('kernel',['uname','-a']),('cpu',['lscpu','-J']),('mount',['findmnt','--json','--target',str(base)]),('block',['lsblk','-J','-b','-o','NAME,TYPE,SIZE,MODEL,MOUNTPOINTS']),('glibc',['getconf','GNU_LIBC_VERSION']),('uptime',['uptime'])]:
 result=subprocess.run(command,capture_output=True,text=True);hardware[name]={'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
hardware['meminfo']=Path('/proc/meminfo').read_text()
(out/'hardware.json').write_text(json.dumps(hardware,indent=2)+'\n')
args=['--profile','campaign','--campaign-metadata','--campaign-timestamp-priority','--items','1000000','--batch','1000','--purge-batch','8000','--shards','64','--workers','2','--load-workers','2','--recycle','--cycles','8','--deadline-seconds','1800','--diagnostic-provenance',str(base/'provenance.json')]
stop=out/'device.stop';pidfile=out/'workload.pid';monitor=None
with (out/'campaign.json').open('w') as f:
 runner=subprocess.Popen(['python3',str(base/'scripts/perf/workflow-capacity.py'),*args],stdout=f,cwd=base)
 while runner.poll() is None:
  ids=subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True,text=True).stdout.split()
  assert len(ids)<=1
  if ids and monitor is None:
   pidfile.write_text(ids[0]);monitor=subprocess.Popen(['python3',str(base/'scripts/perf/fireweed-device-monitor-v3.py'),str(out/'device.jsonl'),str(stop),str(pidfile)])
   print('workload_pid',ids[0],flush=True)
  time.sleep(1)
 if monitor:
  stop.touch();monitor.wait(timeout=5)
  with (out/'device-summary.json').open('w') as summary:
   subprocess.run(['python3',str(base/'scripts/perf/fireweed-device-summary-v3.py'),str(out/'device.jsonl')],stdout=summary,check=True)
print('recorder_exit',runner.returncode,flush=True)
raise SystemExit(runner.returncode)

from pathlib import Path
import collections,json,re,statistics,sys
sys.path.insert(0,'scripts/perf')
from workflow_capacity_gate import qualify
b=Path(sys.argv[1]);d=json.loads((b/'campaign.json').read_text());events=[];cycle_counts=collections.Counter();active=0
for line in d['stderr'].splitlines():
 if line.startswith('campaign_cycle_complete '):
  row=json.loads(line[line.index('{'):]);cycle_counts[row['cycle']]+=1
  if cycle_counts[row['cycle']]==128:active=row['cycle']+1
 elif line.startswith('auto_checkpoint '):
  m=re.fullmatch(r'auto_checkpoint db=(".*") started_unix_us=(\d+) elapsed_us=(\d+) result=(ok|error)(?: max_frame=(\d+) total_backfilled=(\d+) checkpoint_backfilled=(\d+))?',line);assert m,line
  path=json.loads(m[1]);events.append({'path':path,'shard':int(re.search(r'/shard-(\d+)/',path)[1]),'started_unix_us':int(m[2]),'elapsed_us':int(m[3]),'result':m[4],'max_frame':int(m[5]) if m[5] else None,'total_backfilled':int(m[6]) if m[6] else None,'checkpoint_backfilled':int(m[7]) if m[7] else None,'report_interval':active})
assert len(events)==106 and all(cycle_counts[n]==128 for n in range(8))
sums=collections.defaultdict(int)
for e in events:sums[e['shard']]+=e['elapsed_us']
cycles=[]
for n in range(8):
 cases=[(s['shard'],c['campaign'],c['cycles'][n]) for s in d['result']['shards'] for c in s['campaigns']]
 shard,campaign,row=min(cases,key=lambda x:x[2]['items']/x[2]['wall_s'])
 cycles.append({'cycle':n,'slowest_shard':shard,'slowest_campaign':campaign,'equivalent_rate':row['items']/row['wall_s']*128,'wall_s':row['wall_s'],'checkpoint_elapsed_on_slowest_store_in_report_interval_s':sum(e['elapsed_us'] for e in events if e['shard']==shard and e['report_interval']==n)/1e6})
gate=qualify(d,campaign_target=12500)
summary={'scope':'Full on-disk original-row 1M-resident/8M diagnostic with checkpoint and VFS traces; not qualification','source':d['head'],'binary_sha256':d['binary_sha256'],'dirty':d['dirty'],'diagnostics':d['diagnostics'],'child_exit':d['exit_code'],'overall_rate':d['result']['completed_lifecycles_per_s'],'cpu_ms_per_recipient':(d['user_cpu_s']+d['system_cpu_s'])*1000/8000000,'rss_gib':d['max_rss_kib']/2**20,'events':len(events),'statuses':dict(collections.Counter(e['result'] for e in events)),'successful_stores':len(set(e['shard'] for e in events if e['result']=='ok')),'report_intervals':dict(collections.Counter(e['report_interval'] for e in events)),'aggregate_elapsed_s_not_wall_time':sum(e['elapsed_us'] for e in events)/1e6,'maximum_event_s':max(e['elapsed_us'] for e in events)/1e6,'median_event_s':statistics.median(e['elapsed_us'] for e in events)/1e6,'maximum_store_cumulative_s':max(sums.values())/1e6,'store_elapsed_s':{str(k):v/1e6 for k,v in sorted(sums.items())},'cycles':cycles,'qualification':{'passed':gate['passed'],'checks':len(gate['checks']),'failed_checks':[c for c in gate['checks'] if not c['passed']]},'limits':['Checkpoint events run concurrently across stores; sums are not wall time.','Report intervals follow completed 128-campaign groups in stderr, not independently instrumented phase boundaries.','Five maintenance failures have no recorded cause and cannot be classified as I/O errors; all stores eventually report checkpoint success.','This run does not isolate indirect contention between projection writes and durable-log publication.','Timings from this diagnostic do not establish bounds for every run or hardware state.']}
(b/'checkpoint-events.json').write_text(json.dumps(events,indent=2)+'\n');(b/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['cycles','store_elapsed_s','limits']},indent=2))

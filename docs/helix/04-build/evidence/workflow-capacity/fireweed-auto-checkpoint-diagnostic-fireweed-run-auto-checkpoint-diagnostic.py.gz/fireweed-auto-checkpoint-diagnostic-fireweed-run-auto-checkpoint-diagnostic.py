from pathlib import Path
import hashlib,json,os,re,subprocess,time
repo=Path('/home/erik/Projects/fireweed');out=repo/'target/workflow-capacity/auto-checkpoint-diagnostic-20260916'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
out.mkdir(exist_ok=False)
binary=repo/'target/release/fireweed-workload'
assert not subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+' '],capture_output=True).stdout.strip()
with binary.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
provenance={'purpose':'Measure foreground post-WAL-publication auto-checkpoint elapsed time across a full original-row campaign; diagnostic only','source':head,'binary_sha256':digest,'timer_scope':'WAL publication through auto-checkpoint terminal result, including release of WAL transaction locks, I/O yields and scheduling delays; excludes subsequent savepoint cleanup and trace emission','not_device_service_time':True}
prov=out/'provenance.json';prov.write_text(json.dumps(provenance,indent=2)+'\n')
for key in ['FIREWEED_PROJECTION_IO_TRACE','FIREWEED_APPLY_TRACE','FIREWEED_SQL_TRACE','FIREWEED_LOG_TRACE','OBJECT_LOG_LOCAL_PUBLISH_TRACE','LD_PRELOAD']:
 assert key not in os.environ,key
args=['--profile','campaign','--campaign-metadata','--campaign-timestamp-priority','--items','1000000','--batch','1000','--purge-batch','8000','--shards','64','--workers','2','--load-workers','2','--recycle','--cycles','8','--deadline-seconds','1800','--diagnostic-provenance',str(prov)]
monitor=None;prefix=out/'device';stop=out/'device.stop';pidfile=out/'workload.pid'
with (out/'campaign.json').open('w') as f:
 child=subprocess.Popen(['python3','scripts/perf/workflow-capacity.py',*args],cwd=repo,env=dict(os.environ,FIREWEED_PROJECTION_IO_TRACE='1'),stdout=f)
 while child.poll() is None:
  ids=subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+' '],capture_output=True,text=True).stdout.split()
  assert len(ids)<=1
  if ids and monitor is None:
   pidfile.write_text(ids[0]);monitor=subprocess.Popen(['python3','/tmp/fireweed-device-monitor-v3.py',str(prefix)+'.jsonl',str(stop),str(pidfile)])
   print('observed workload',ids[0],flush=True)
  time.sleep(1)
if monitor is not None:
 stop.touch();monitor.wait(timeout=5)
 with (out/'device-summary.json').open('w') as f:subprocess.run(['python3','/tmp/fireweed-device-summary-v3.py',str(prefix)+'.jsonl'],stdout=f,check=True)
d=json.loads((out/'campaign.json').read_text());assert child.returncode==0 and d['exit_code']==0
assert d['binary_sha256']==digest and d['head']==head and not d['dirty']
assert d['diagnostics']=={'FIREWEED_PROJECTION_IO_TRACE':'1'}
print('diagnostic complete',d['result']['completed_lifecycles_per_s'],flush=True)

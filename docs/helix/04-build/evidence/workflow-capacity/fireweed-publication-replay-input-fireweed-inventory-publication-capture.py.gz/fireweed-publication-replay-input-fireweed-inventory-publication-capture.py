from pathlib import Path
import hashlib,json
base=Path('/home/erik/Projects/fireweed/target/workflow-capacity/publication-capture-20260916')
files=sorted([*base.glob('source/shard-*/log/*/fwlog/*'),*base.glob('source/shard-*/log/*/fwmeta/manifest/*')])
entries=[]
for p in files:
 assert p.is_file() and len(p.name)==20 and p.name.isdigit(),p
 with p.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 entries.append({'path':str(p.relative_to(base)),'bytes':p.stat().st_size,'sha256':digest})
result={'capture_report_sha256':hashlib.sha256((base/'capture.json').read_bytes()).hexdigest(),'immutable_file_count':len(entries),'data_objects':sum('/fwlog/' in e['path'] for e in entries),'manifests':sum('/manifest/' in e['path'] for e in entries),'immutable_bytes':sum(e['bytes'] for e in entries),'source_root':str(base),'note':'Exact input retained locally; inventory is not a substitute for file contents. Other log snapshot files and their overwritten publication history are excluded from replay.','files':entries}
(base/'immutable-inventory.json').write_text(json.dumps(result,indent=2)+'\n')
print({k:v for k,v in result.items() if k!='files'})

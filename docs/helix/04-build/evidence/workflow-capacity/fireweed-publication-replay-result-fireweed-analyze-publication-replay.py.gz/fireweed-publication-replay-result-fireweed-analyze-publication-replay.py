from pathlib import Path
import json,sys
base=Path(sys.argv[1]);d=json.loads((base/'result.json').read_text());usage=json.loads((base/'usage.json').read_text());rows=d['cycles'];samples=[json.loads(x) for x in (base/'device.jsonl').read_text().splitlines()]
assert usage['exit_code']==0 and len(rows)==32 and d['verified_objects']==351040
for row in rows:
 assert len(row['stores'])==64
 assert sum(s['publications'] for s in row['stores'])==10970
 assert sum(s['bytes'] for s in row['stores'])==1802012562
 assert sum(s['media_ops'] for s in row['stores'])==21940
 assert abs(row['publication_only_equivalent_recipients_per_s']-d['captured_recipients']/row['wall_s'])<1e-6

def summarize(part):
 wall=sum(r['wall_s'] for r in part);items=d['captured_recipients']*len(part);logical=sum(s['bytes'] for r in part for s in r['stores'])
 eligible=[s for s in samples if part[0]['started_unix_s']<=s['wall_time_s']<=part[-1]['finished_unix_s']]
 a,b=eligible[0],eligible[-1];dt=b['monotonic_s']-a['monotonic_s'];x,y=a['nvme0n1'],b['nvme0n1'];writes=y[4]-x[4]
 return {'first_cycle':part[0]['cycle'],'last_cycle':part[-1]['cycle'],'timed_wall_s':wall,'publication_only_equivalent_recipients_per_s':items/wall,'minimum_cycle_equivalent_rate':min(r['publication_only_equivalent_recipients_per_s'] for r in part),'logical_publication_gib':logical/2**30,'logical_publication_mib_s':logical/2**20/wall,'host_sample_window':{'observed_s':dt,'marker_span_s':part[-1]['finished_unix_s']-part[0]['started_unix_s'],'inter_cycle_gap_s':part[-1]['finished_unix_s']-part[0]['started_unix_s']-wall,'sampled_fraction_of_marker_span':dt/(part[-1]['finished_unix_s']-part[0]['started_unix_s']),'host_wide_not_process_attribution':True,'host_written_gib':(y[6]-x[6])*512/2**30,'host_write_mib_s':(y[6]-x[6])*512/2**20/dt,'device_busy_percent':(y[9]-x[9])/dt/10,'write_iops':writes/dt,'mean_write_request_ms':(y[7]-x[7])/max(1,writes),'mean_outstanding_io':(y[10]-x[10])/1000/dt,'process_cpu_s_per_s':(b['process_cpu_s']-a['process_cpu_s'])/dt}}
r={'not_workflow_qualification':True,'all_objects_verified':True,'verified_objects':d['verified_objects'],'provenance':json.loads((base/'provenance.json').read_text()),'overall':summarize(rows),'groups_of_eight':[summarize(rows[n:n+8]) for n in range(0,32,8)],'conditional_target_budget':{'recipients_per_s':12500,'immutable_publication_bytes_per_recipient':1802012562/1e6,'logical_publication_mib_s':1802012562/1e6*12500/2**20,'native_file_plus_directory_sync_calls_per_s':21940/1e6*12500,'slowest_publication_only_rate_divided_by_target':min(r['publication_only_equivalent_recipients_per_s'] for r in rows)/12500},'limits':d['exclusions']+['One captured cycle repeated in fresh namespaces; no long-lived directory growth','Host counter windows omit boundary gaps, include short inter-cycle gaps and include other processes','Whole-process CPU usage includes preload and byte verification; do not charge it all to publication','Isolation does not model mixed projection/log contention or establish a device ceiling']}
(base/'analysis.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

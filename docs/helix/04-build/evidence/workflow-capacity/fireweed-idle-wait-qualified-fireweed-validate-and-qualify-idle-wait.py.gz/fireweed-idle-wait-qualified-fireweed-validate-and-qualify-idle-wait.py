from pathlib import Path
import os,subprocess
repo=Path('/home/erik/Projects/fireweed')
env=dict(os.environ,CARGO_BUILD_JOBS='8')
with Path('/tmp/fireweed-idle-wait-public-tests.log').open('w') as log:
 subprocess.run(['cargo','test','--locked','--release','-p','fireweed-workload','--test','campaign','--test','primitives','--test','recovery','--','--test-threads=1'],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
print('Public workflow/recovery tests passed; starting serial canonical qualification',flush=True)
subprocess.run(['python3','/tmp/fireweed-run-idle-wait-untraced-qualification.py'],cwd=repo,env=env,check=True)

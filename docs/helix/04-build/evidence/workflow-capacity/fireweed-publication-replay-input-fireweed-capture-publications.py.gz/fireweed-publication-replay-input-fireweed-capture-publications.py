from pathlib import Path
import hashlib,json,os,re,subprocess,time
repo=Path('/home/erik/Projects/fireweed');base=repo/'target/workflow-capacity/publication-capture-20260916'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo).strip()
base.mkdir(exist_ok=False)
binary=Path('/tmp/fireweed-workload-before-directory-sync-sharing')
sha=hashlib.sha256(binary.read_bytes()).hexdigest();assert sha=='9f54d1207211f5c12104bac95e70289479d2fdecd53baa7562926ae60e6a3763'
assert not subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True).stdout.strip()
for key in ('FIREWEED_SQL_TRACE','FIREWEED_APPLY_TRACE','FIREWEED_WORKLOAD_TIMING','FIREWEED_METRICS_TRACE','FIREWEED_LOG_TRACE','FIREWEED_WORKLOAD_DEBUG','LD_PRELOAD','FIREWEED_PROJECTION_IO_TRACE','OBJECT_LOG_LOCAL_PUBLISH_TRACE','OBJECT_LOG_FLUSH_RUNTIME_THREADS'):assert key not in os.environ,key
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
source=(repo/'scripts/perf/workflow-capacity.py').read_text().replace('from workflow_storage_monitor import WalMonitor',"sys.path.insert(0, '/home/erik/Projects/fireweed/scripts/perf')\nfrom workflow_storage_monitor import WalMonitor").replace('repo = Path(__file__).resolve().parents[2]',"repo = Path('/home/erik/Projects/fireweed')").replace('binary = repo / "target/release/fireweed-workload"',"binary = Path('/tmp/fireweed-workload-before-directory-sync-sharing')")
recorder=Path('/tmp/fireweed-publication-capture-recorder.py');recorder.write_text(source)
provenance={'diagnostic_only':True,'build_source_head':'4f4acde08a76d2a94ecbc08443a49d9f38003e39','executable_sha256':sha,'recorder_source_head':head,'recorder_sha256':hashlib.sha256(source.encode()).hexdigest(),'purpose':'Capture exact immutable data/manifest objects from one complete original-row campaign for publication-path isolation; not sustained qualification'}
prov=base/'provenance.json';prov.write_text(json.dumps(provenance,indent=2)+'\n')
args=['--profile','campaign','--campaign-metadata','--campaign-timestamp-priority','--items','1000000','--batch','1000','--purge-batch','8000','--shards','64','--workers','2','--load-workers','2','--recycle','--cycles','1','--deadline-seconds','900','--root',str(base/'source'),'--diagnostic-provenance',str(prov)]
monitor=None;stop=base/'device.stop';pidfile=base/'workload.pid'
with (base/'capture.json').open('w') as out:
 runner=subprocess.Popen(['python3',str(recorder),*args],cwd=repo,stdout=out)
 while runner.poll() is None:
  ids=subprocess.run(['pgrep','-f','^'+re.escape(str(binary))+r'( |$)'],capture_output=True,text=True).stdout.split();assert len(ids)<=1
  if ids and monitor is None:
   pidfile.write_text(ids[0]);monitor=subprocess.Popen(['python3','/tmp/fireweed-device-monitor-v3.py',str(base/'device.jsonl'),str(stop),str(pidfile)])
   print('capture workload pid',ids[0],flush=True)
  time.sleep(1)
if monitor is not None:
 stop.touch();monitor.wait(timeout=5)
 with (base/'device-summary.json').open('w') as f:subprocess.run(['python3','/tmp/fireweed-device-summary-v3.py',str(base/'device.jsonl')],stdout=f,check=True)
d=json.loads((base/'capture.json').read_text());assert runner.returncode==0 and d['exit_code']==0,d.get('stderr')
print('captured',d['result']['items'],'recipients at',d['result']['completed_lifecycles_per_s'],'source',base/'source',flush=True)

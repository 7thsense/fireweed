#!/usr/bin/env bash
set -euo pipefail
cd /home/erik/Projects/fireweed
output=target/workflow-capacity/owned-params-repeat-20260916
mkdir -- "$output"
cp target/workflow-capacity/owned-params-eight-20260916.json "$output/campaign-1.json"
failed=1 # Preserve campaign 1's failed stretch gate; evaluate 10k separately.
if ! python3 scripts/perf/workflow-capacity.py --profile primitives --primitive-varied-payload --items 1000000 --batch 1000 --shards 32 --deadline-seconds 900 --qualify > "$output/primitives-1.json"; then failed=1; fi
if ! python3 scripts/perf/workflow-capacity.py --profile campaign --campaign-metadata --campaign-timestamp-priority --items 1000000 --batch 1000 --purge-batch 8000 --shards 64 --workers 2 --load-workers 2 --recycle --cycles 8 --deadline-seconds 1800 --stretch > "$output/campaign-2.json"; then failed=1; fi
if ! python3 scripts/perf/workflow-capacity.py --profile primitives --primitive-varied-payload --items 1000000 --batch 1000 --shards 32 --deadline-seconds 900 --qualify > "$output/primitives-2.json"; then failed=1; fi
exit "$failed"
